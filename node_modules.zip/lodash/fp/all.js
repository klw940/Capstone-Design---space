module.exports = require('./every');
