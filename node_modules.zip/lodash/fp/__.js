module.exports = require('./placeholder');
