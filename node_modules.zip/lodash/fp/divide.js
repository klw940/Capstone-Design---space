var convert = require('./convert'),
    func = convert('divide', require('../divide'));

func.placeholder = require('./placeholder');
module.exports = func;
