module.exports = require('./dropRight');
