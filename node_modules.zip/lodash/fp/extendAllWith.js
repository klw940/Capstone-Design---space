module.exports = require('./assignInAllWith');
