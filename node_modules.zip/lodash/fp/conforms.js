module.exports = require('./conformsTo');
