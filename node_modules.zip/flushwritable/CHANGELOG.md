# FlushWritable
A Writable stream that flushes before emitting finish.

##ChangeLog

### v1.0.0
- **Initial Public Release**
