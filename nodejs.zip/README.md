[http://a-mean-blog.com/ko/blog/Node-JS-첫걸음/주소록-만들기](http://a-mean-blog.com/ko/blog/Node-JS-첫걸음/주소록-만들기) 을 토대로 작성하였습니다.
