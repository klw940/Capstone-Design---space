module.exports = {
    'secret': 'droneDiyKimsPaCEBK',
    'mongodbUri': 'mongodb://localhost:27017/test'
}
