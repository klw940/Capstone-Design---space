var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//자유게시판 댓글(freeComment)
var CommentSchema = new Schema({
    number : Number,//댓글 id(댓글간에 구별 가능하게) (id)
    writer : String,//작성자 id (name)
    contents : String,//내용
},{collection:'freeComment'});

module.exports = mongoose.model('freeComment', CommentSchema);
