var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//자유 게시판
var BoardSchema = new Schema({
    number : Number,//글번호 또는 id
    title : String,//제목
    writer : String,//작성자
    contents : String,//내용
    date : String,//작성날짜
    hits : Number//조회수
},{collection:'freeboard'});

module.exports = mongoose.model('freeboard', BoardSchema);
