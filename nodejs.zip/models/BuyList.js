var mongoose=require('mongoose');
var Schema = mongoose.Schema;

var BuyListSchema = new Schema({
	name : {type : String, expires : '10s'},
    email : String,
    address : String,
	check : {type: Boolean, default: false},
	list : Array
},{collection:'buylist'});

module.exports = mongoose.model('buylist', BuyListSchema);