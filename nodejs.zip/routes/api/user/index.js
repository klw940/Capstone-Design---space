/*const router = require('express').Router()
const controller = require('./user.controller')

router.get('/list', controller.list)
router.post('/assign-admin/:username', controller.assignAdmin)

module.exports = router

 관리자 기능
 /list 모든 회원 출력
 /assign-admin/:username 권한 주기
*/