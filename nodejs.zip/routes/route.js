//route

var express=require('express');
var router = express.Router();
//var moment = require('moment');
//require('moment-timezone');
//moment.tz.setDefault("Asiz/Seoul");
//////////디비 추가/////////
var BoardModel = require('../models/BoardModel');
var Member = require ('../models/Member');
var Drone = require('../models/DroneModel');
var freeboard = require('../models/BoardModel');
var buylist = require('../models/BuyList');
var reply = require('../models/CommentModel');
var MongoClient = require('mongodb').MongoClient; ////
var url = "mongodb://localhost/test";
////////////////////////////
var signActions =require('../auth/signActions');

const multer = require('multer'); // multer모듈 적용 (for 파일업로드)
const upload = multer({
    storage: multer.diskStorage({
      destination: function (req, file, cb) {
        cb(null, 'uploads/');
      },
      filename(req, file, cb) {
        cb(null, file.originalname);
      }
    }),
  });


var flag;
var frame = new Array();
var wing = new Array();
var cb = new Array();
var esc = new Array();
var battery = new Array();
var ant = new Array();
var motor = new Array();
/*
0: price, 1: weight, 2: long_length, 3: short_length, 4: store, 5: HOU, 6: rating, 7: thrust
*/

var index; // 구매목록 인덱스 관리하는거

const fs =require('fs');

function DB(){
	this.db=null;
}

router.get('/', function(req,res){
	res.sendFile('/home/ec2-user/temp/build/index.html');
});

//QnA게시판
router.get('/board_list',function(req,res){
	BoardModel.find({})
		   .exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});

router.get('/member',function(req,res){
	Member.find({})
            	.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});
/* 드론 견적 */
router.get('/drone',function(req,res){
	Drone.find({"part":{$eq:1}})
		.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});
router.post('/drone',function(req,res){
	console.log("post drone");
	console.log("------------------------------------");
	flag = req.body.part;
	if(flag==1){
		frame[0] = req.body.price;
		frame[1] = req.body.weight;
		frame[2] = req.body.long_length;
		frame[3] = req.body.short_length;
        frame[4] = req.body.store;
		Drone.find({$and:[{"part":{$eq:2}}, {"store": {$ne:0}}, {"long_length": {$lt:frame[2]}}]})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
				
			console.log("=============================frame==================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
	}
	else if(flag==2){
		wing[0] = req.body.price;
		wing[1] = req.body.weight;
		wing[2] = req.body.long_length;
		wing[3] = req.body.short_length;
		wing[4] = req.body.store;
		Drone.find({$or:[{$and:[{"part":{$eq:1}},{"store":{$ne:0}}]} , {$and:[{"part":{$eq:3}}, {"store": {$ne:0}}, {"short_length": {$lt:frame[3]}}]}]})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("=============================Wings==================================")
			console.log(boards);
			console.log("====================================================================")	
			res.json(boards);
			});
	}
	else if(flag==3){
		cb[0] = req.body.price;
		cb[1] = req.body.weight;
		cb[2] = req.body.long_length;
		cb[3] = req.body.short_length;
		cb[4] = req.body.store;
		var num;
		num = frame[3]-cb[3];
		Drone.find( {$or:[ {$and:[ {"part":{$eq:2} }, {"store": {$ne:0} }, {"long_length": {$lt:frame[2] } } ] }, { $and: [ {"part":{$eq:4} }, {"store":{$ne:0} }, {"short_length": {$lt:num} } ] } ] } )  
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("===============================CB===================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
	}
	else if(flag==4){
		esc[0] = req.body.price;
		esc[1] = req.body.weight;
		esc[2] = req.body.long_length;
		esc[3] = req.body.short_length;
		esc[4] = req.body.store;
		Drone.find({$or:[{$and:[{"part":{$eq:3}} , {"store": {$ne:0}}, {"short_length": {$lt:frame[3]}}]}, {$and: [{"part":{$eq:5} }, {"store": {$ne:0}}]}]})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("==============================ESC===================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
	}
	else if(flag==5){
		battery[0] = req.body.price;
		battery[1] = req.body.weight;
		battery[2] = req.body.long_length;
		battery[3] = req.body.short_length;
		battery[4] = req.body.store;
		battery[5] = req.body.HOU;
		Drone.find( {$or:[ {$and:[ {"part":{$eq:4} }, {"store": {$ne:0}}, {"short_length": {$lt:frame[3] } } ] }, {$and: [{"part":{$eq:6} }, {"store": {$ne:0}}]}]})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("============================battery=================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
	}
	else if(flag==6){
		ant[0] = req.body.price;
		ant[1] = req.body.weight;
		ant[2] = req.body.long_length;
		ant[3] = req.body.short_length;
		ant[4] = req.body.store;
		ant[5] = req.body.rating;

		var weightSum;
		weightSum += frame[1];
		weightSum += wing[1];
		weightSum += cb[1];
		weightSum += esc[1];
		weightSum += battery[1];
		weightSum += ant[1];
		var arr = new Array();
		Drone.find(  {$or:[  {$and:[ {"part":{$eq:5} }, {"store":{$ne:0}} ] },{$and:[ {"part":{$eq:7} }, {"store":{$ne:0}} ] } ] },        {$where:function(){return this.weight+weightSum < this.thrust} } )
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("============================Antenna=================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
		/*Drone.find({"part": {$eq:7}}).$where(function(){
 return this.weight+weightSum < thrust;
})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log(boards);
			res.json(boards);
			});*/
	}
	else if(flag==7){
		motor[0] = req.body.price;
		motor[1] = req.body.weight;
		motor[2] = req.body.long_length;
		motor[3] = req.body.short_length;
		motor[4] = req.body.store;
		motor[5] = req.body.HOU;
		motor[6] = req.body.rating
		motor[7] = req.body.thrust;
		var priceSum;

		priceSum += frame[0];
		priceSum += wing[0];
		priceSum += cb[0];
		priceSum += esc[0];
		priceSum += battery[0];
		priceSum += ant[0];
		priceSum += motor[0];
		Drone.find({"part":{$eq:6}})
			.exec(function(err,boards){
				if(err) res.status(403).json({success:false});
			console.log("============================Motor=================================")
			console.log(boards);
			console.log("====================================================================")
			res.json(boards);
			});
		/*if(weightSum >= motor[7]){
			res.send("Motor's thrust is not enough!!! Please select another motor.");
		}
		else if(weightSum < motor[7]){
			res.send("OK");
		}*/
	}
});
/*드론 견적 종료*/

/*부품 구매*/
router.get('/buy',function(req,res){
	Drone.find({"store":{$ne:0}})
		.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});

/*부품 판매 등록(tempDB에)*/
router.post('/part_sale', upload.single('img'), function(req,res){
    MongoClient.connect(url, function(err, db){
        if(err) throw err;
		var dbo = db.db("test");
		var product;
			if(req.body.part == 7 || req.body.part ==2){
				product ={
					"name" : req.body.name,
					"image": "http://54.180.90.44:3001/"+req.file.path,
					"price" : Number(req.body.price),
					"weight": 4*Number(req.body.weight),
					"long_length" : Number(req.body.long_length),
					"short_length": Number(req.body.short_length),
					"height": Number(req.body.height), 
					"store":Number(req.body.store),
					"description":req.body.description,
					"part": Number(req.body.part),
					"thrust" : 4*Number(req.body.thrust),
					"HOU": Number(req.body.HOU),
					"rating":Number(req.body.rating),
					"material":req.body.material
				};
			}
			else{
				product ={
					"name" : req.body.name,
					"image": "http://54.180.90.44:3001/"+req.file.path,
					"price" : Number(req.body.price),
					"weight": Number(req.body.weight),
					"long_length" : Number(req.body.long_length),
					"short_length": Number(req.body.short_length),
					"height": Number(req.body.height), 
					"store":Number(req.body.store),
					"description":req.body.description,
					"part": Number(req.body.part),
					"thrust" : Number(req.body.thrust),
					"HOU": Number(req.body.HOU),
					"rating":Number(req.body.rating),
					"material":req.body.material
				};
			}
    dbo.collection("drone").insert(product, function(err,result){
        if(err) throw err;
        //res.redirect('/');
        console.log(req.body.part);
        console.log("----------------------body Part--------------------");
        console.log(req.file.path);
        res.send("True");
        });
    });
});


/* 자유게시판 */
//freeboard디비에서 게시판 내용 불러오는거
router.get('/freeboard',function(req,res){
    freeboard.find({})
        .sort({"number":-1})
		.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
        res.json(boards);
        
		});
});

//게시판 글 보기
router.get('/freeboard/:id',function(req,res){
	freeboard.find({})
		// .exec(function(err, boards){
			// if(err) res.status(403).json({success:false});
		// console.log(boards);
		res.json(id);
		// });
});
//게시판에 글쓰는거
router.post('/free_write', function(req,res){
    MongoClient.connect(url, function(err, db){
        if(err) throw err;
        var dbo = db.db("test");
        var product ={
      "number": req.body.number,
      "title": req.body.title,
      "writer": req.body.writer,
      "contents": req.body.contents,
      "date": req.body.date
    };
    dbo.collection("freeboard").insert(product, function(err,result){
        if(err) throw err;
        //console.log(Date.now());
        console.log(req.body);
        console.log("글 삭제");
       
        });
    });
});

//게시판 글 삭제하는거
router.post('/free_delete', function(req,res){
    MongoClient.connect(url, function(err, db){
        var deleteName = req.body.write;
		freeboard.deleteOne({"write":{$eq:deleteName}})
		.exec(function(err,boards){
			if(err) res.status(403).json({success:false});
		console.log("============================삭제완료=================================")
		res.send("OK");
		});
	});
});

//게시판 글 수정
router.post('/free_modify', function(req,res){
    MongoClient.connect(url, function(err, db){
		var modifyName = req.body.writer;
		var myquery = {"writer": modifyName};
		var newvalues = {"contents": req.body.contents};
		freeboard.updateOne(myquery, newvalues)
		.exec(function(err,boards){
			if(err) res.status(403).json({success:false});
		console.log("============================수정완료=================================")
		res.send("OK");
		});
	});
});

//buylist 데이터베이스에 구매목록 넣는거
router.post('/buy_list', function(req,res){
    MongoClient.connect(url, function(err, db){
        if(err) throw err;
        var dbo = db.db("test");
        var myquery = req.body.list[0].info.name;
        var newvalues=req.body.list[0].info.store;
        var product ={
        "name": req.body.name,
        "email": req.body.email,
        "address": req.body.address,
        "list": req.body.list
    };
    dbo.collection("drone").updateOne({"name" : myquery}, {$set : { "store": newvalues}});
  
    dbo.collection("buylist").insert(product, function(err,result){
        if(err) throw err;
        console.log("------------------------구매목록--------------------------");
      console.log(req.body);
      res.json(newvalues);
       });
    });
});

router.get('/buy_list',function(req,res){
	buylist.find({})
		.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});

//드론 판매 디비에서 삭제
router.post('/drone_delete', function(req,res){
    MongoClient.connect(url, function(err, db){
        var deleteName = req.body._id;
		Drone.deleteOne({"_id":{$eq:deleteName}})
		.exec(function(err,boards){
			if(err) res.status(403).json({success:false});
        console.log("============================내용=================================")
        console.log(req.body._id);
		res.send("True");
		});
	});
});

//프론트에서 buylist 디비 값의 _id를 받아서 check 값을 true로 수정하는곳
router.post('/buy_list_check', function(req,res){
	var ObjectId = require('mongodb').ObjectID;
    MongoClient.connect(url, function(err, db){
        var dbo =db.db("test");
		var myquery = req.body._id;
		dbo.collection("buylist").updateOne({"_id" : ObjectId(myquery)}, {$set : {"check": true}});
		buylist.find({"_id" : myquery}).exec(function(err,boards){
			if(err) res.status(403).json({success:false});
        console.log("============================내용=================================")
        console.log(req.body);
		res.json(boards);
		});
	});
	
});

//관리자가 재고량 변화 시켰을 때
router.post('/change_store', function(req,res){
    var ObjectId = require('mongodb').ObjectID;
    MongoClient.connect(url, function(err, db){
        if(err) throw err;
        var dbo = db.db("test");
        var myquery = req.body._id;
        var newvalues = req.body.store;
    dbo.collection("drone").updateOne({"_id": ObjectId(myquery)}, {$set : {"store": newvalues}});
    res.json(ObjectId(myquery));
    });
});

//농업용 드론 추천
router.get('/reco_farm',function(req,res){
    res.json([
    {"name":"Readytosky VX210-V2 210mm FPV Racing Drone Frame 3", 
    "image": "http://54.180.90.44:3001/uploads/frame2.png",
    "price": 62900,
    "weight":87.5,
    "long_length":21,
    "short_length":21,
    "height":9,
    "store":30,
    "description":"very popular design",
    "part":1,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":"3k carbon fiber"},////프레임끝

    {"name":"DJI 스파크 퀵 릴리즈 접이식",
    "image": "http://54.180.90.44:3001/uploads/프로펠러4.png",
    "price": 10410,
    "weight":10,
    "long_length":11.94,
    "short_length":5.89,
    "height":7.62,
    "store":30,
    "description":"expensive",
    "part":2,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":"플라스틱"},///날개 끝

    {"name":"Airbot F4 MPU9250 컨트롤 보드",
    "image": "http://54.180.90.44:3001/uploads/컨트롤보드3.jpg",
    "price": 36900,
    "weight":4.2,
    "long_length":3.5,
    "short_length":3.5,
    "height":3,
    "store":30,
    "description":"string design",
    "part":3,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///컨트롤보드 끝

    {"name":"330/450 Class Quadcopter",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/%EB%B3%80%EC%86%8D%EA%B8%B0_3.jpg?raw=true",
    "price": 16000,
    "weight":14,
    "long_length":5.24,
    "short_length":2.15,
    "height":0.7,
    "store":99,
    "description":"ESC3",
    "part":4,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///변속기 끝

    {"name":"EP파워 3.7V 7800mah Liion 배터리",
    "image": "http://54.180.90.44:3001/uploads/EP파워 3.7V 7800mah Liion 배터리.jpg",
    "price": 36000,
    "weight":70,
    "long_length":6.9,
    "short_length":5.6,
    "height":2,
    "store":30,
    "description":"중형",
    "part":5,
    "thrust":0,
    "HOU":700,
    "rating":0,
    "material":""},///배터리 끝

    {"name":"TBS Cloverleaf Antenna for Unify Pro",
    "image": "http://54.180.90.44:3001/uploads/안테나9.png",
    "price": 9900,
    "weight":1.7,
    "long_length":3,
    "short_length":6,
    "height":10,
    "store":30,
    "description":"안테나",
    "part":6,
    "thrust":0,
    "HOU":0,
    "rating":40,
    "material":""},///안테나 끝

    {"name":"U11 KV90",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/motor6.jpg?raw=true",
    "price": 395000,
    "weight":815,
    "long_length":8,
    "short_length":4,
    "height":5.14,
    "store":10,
    "description":"모터 6입니다",
    "part":7,
    "thrust":5000,
    "HOU":0,
    "rating":0,
    "material":""}]///모터 끝
    );
});

//레이싱 드론
router.get('/reco_race',function(req,res){
    res.json([
    {"name":"Frame3", 
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/Frame3.jpg?raw=true",
    "price": 22000,
    "weight":130,
    "long_length":25,
    "short_length":12.5,
    "height":5,
    "store":9998,
    "description":"very popular design",
    "part":1,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":"plastic"},////프레임끝

    {"name":"나인이글 갤럭시비지터 6 ",
    "image": "http://54.180.90.44:3001/uploads/%ED%94%84%EB%A1%9C%ED%8E%A0%EB%9F%AC3.png",
    "price": 5780,
    "weight":20,
    "long_length":10,
    "short_length":5,
    "height":3,
    "store":29,
    "description":"expensive",
    "part":2,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":"플라스틱"},///날개 끝

    {"name":"APM 2.8 ArduPilot Mega",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/CB5.jpg?raw=true",
    "price": 50000,
    "weight":7,
    "long_length":6,
    "short_length":3,
    "height":1,
    "store":4,
    "description":"string design",
    "part":3,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///컨트롤보드 끝

    {"name":"Xrotor 20A 4IN1 Micro",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/%EB%B3%80%EC%86%8D%EA%B8%B0_5.jpg?raw=true",
    "price": 46000,
    "weight":24.5,
    "long_length":5.4,
    "short_length":3.6,
    "height":0.7,
    "store":98,
    "description":"ESC3",
    "part":4,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///변속기 끝

    {"name":"PEAKPOWER 1100mah 3.7V 25C 리포배터리",
    "image": "http://54.180.90.44:3001/uploads/PEAKPOWER%201100mah%203.7V%2025C%20%EB%A6%AC%ED%8F%AC%EB%B0%B0%ED%84%B0%EB%A6%AC.jpg",
    "price": 7800,
    "weight":19,
    "long_length":5.2,
    "short_length":2.9,
    "height":1,
    "store":29,
    "description":"중형",
    "part":5,
    "thrust":0,
    "HOU":20,
    "rating":0,
    "material":""},///배터리 끝

    {"name":"TX ANTENNA (4PK) - 4PK 용 송신기 안테나",
    "image": "http://54.180.90.44:3001/uploads/%EC%95%88%ED%85%8C%EB%82%985.jpg",
    "price": 35000,
    "weight":11,
    "long_length":3,
    "short_length":2,
    "height":10,
    "store":29,
    "description":"안테나",
    "part":6,
    "thrust":0,
    "HOU":0,
    "rating":30,
    "material":""},///안테나 끝

    {"name":"SYMA X5C",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/motor8.jpg?raw=true",
    "price": 20000,
    "weight":170,
    "long_length":2.82,
    "short_length":1.41,
    "height":4,
    "store":9,
    "description":"모터 6입니다",
    "part":7,
    "thrust":850,
    "HOU":0,
    "rating":0,
    "material":""}]///모터 끝
    );
});

//촬영용 드론 추천
router.get('/reco_camera',function(req,res){
    res.json([
    {"name":"Readytosky 235mm FPV Racing Drone Frame 3k Full Ca", 
    "image": "http://54.180.90.44:3001/uploads/frame3.png",
    "price": 64800,
    "weight":117.4,
    "long_length":23.5,
    "short_length":23.5,
    "height":10,
    "store":30,
    "description":"very nice design",
    "part":1,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":"3k carbon fiber"},////프레임끝

    {"name":"Wing1",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/wings-ex.jpg?raw=true",
    "price": 15000,
    "weight":0.4,
    "long_length":20,
    "short_length":5,
    "height":3,
    "store":30,
    "description":"날개1입니다.",
    "part":2,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///날개 끝

    {"name":"FPV-LSCB",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/CB4.jpg?raw=true",
    "price": 30000,
    "weight":3,
    "long_length":3,
    "short_length":3,
    "height":1,
    "store":30,
    "description":"CB3",
    "part":3,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///컨트롤보드 끝

    {"name":"XRotor 20A Micro (3~4S)",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/%EB%B3%80%EC%86%8D%EA%B8%B0_4.jpg?raw=true",
    "price": 16500,
    "weight":6.8,
    "long_length":2.4,
    "short_length":1.2,
    "height":0.43,
    "store":98,
    "description":"ESC4",
    "part":4,
    "thrust":0,
    "HOU":0,
    "rating":0,
    "material":""},///변속기 끝

    {"name":"EP파워 3.7V 7800mah Liion 배터리",
    "image": "http://54.180.90.44:3001/uploads/EP파워 3.7V 7800mah Liion 배터리.jpg",
    "price": 36000,
    "weight":70,
    "long_length":6.9,
    "short_length":5.6,
    "height":2,
    "store":30,
    "description":"중형",
    "part":5,
    "thrust":0,
    "HOU":700,
    "rating":0,
    "material":""},///배터리 끝

    {"name":"TX ANTENNA for 8FG 18SZ 18MZ FUT",
    "image": "http://54.180.90.44:3001/uploads/%EC%95%88%ED%85%8C%EB%82%981.jpg",
    "price": 36000,
    "weight":10,
    "long_length":3,
    "short_length":2,
    "height":7,
    "store":29,
    "description":"안테나",
    "part":6,
    "thrust":0,
    "HOU":0,
    "rating":10,
    "material":""},///안테나 끝

    {"name":"U8 KV170",
    "image": "https://github.com/klw940/Capstone-Design---space/blob/master/src/image/motor4.jpg?raw=true",
    "price": 310000,
    "weight":242,
    "long_length":8.68,
    "short_length":4.34,
    "height":2.65,
    "store":9,
    "description":"모터 4입니다",
    "part":7,
    "thrust":2000,
    "HOU":0,
    "rating":0,
    "material":""}]///모터 끝
    );
});
/* 댓글작성put reply*/
router.post('/put_reply', function(req, res){
    //게시글 id, 댓글작성자, 댓글 내용
    
    MongoClient.connect(url, function(err, db){
        var dbo =db.db("test");
        var product ={
            "number":  req.body.number,
            "writer" :req.body.name,
            "contents" : req.body.contents
          };
		dbo.collection("freeComment").insert(product, function(err,result){
            if(err) throw err;
            console.log(req.body)
            res.send("True");
            });
	});
});
/* get reply 글number만 response로 댓글전부다, 댓글은 내용 작성자*/
router.post('/get_reply',function(req,res){
    var number = req.body.number;
    console.log(req.body);
	reply.find({"number":{$eq:number}})
		.exec(function(err, boards){
			if(err) res.status(403).json({success:false});
		console.log(boards);
		res.json(boards);
		});
});

router.post('/sign-up', signActions.signUp);
router.post('/login', signActions.signIn);

module.exports = router;